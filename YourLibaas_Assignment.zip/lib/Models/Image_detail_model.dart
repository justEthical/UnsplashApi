class ImageDetail {
  String? thumb;
  String? img;
  String? id;
  String? blurhash;

  ImageDetail(this.id, this.blurhash, this.img, this.thumb);
}
